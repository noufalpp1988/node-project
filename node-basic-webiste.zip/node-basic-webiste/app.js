var express = require("express");
var $ = require('jquery');

var app = express();

//var todoController=require('./controllers/todoController');
var homeController = require('./controllers/homeController'),
    insuranceController = require('./controllers/insuranceController'),
    aboutController = require('./controllers/aboutController'),
    contactController = require('./controllers/contactController');

app.set("view engine", "ejs");

var bodyParser = require("body-parser");
var urlEncodedParser = bodyParser.urlencoded({ extended: false });

app.use(express.static("./public")); // defaulting to public folder

//fire controller
//todoController(app);
homeController(app, urlEncodedParser);
insuranceController(app);
aboutController(app, urlEncodedParser);
contactController(app, urlEncodedParser);


app.listen(8080);
console.log("server runnig on 8080...");

