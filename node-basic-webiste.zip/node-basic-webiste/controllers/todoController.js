
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

// connect to db
// https://mlab.com/databases/todo/collections/todos

mongoose.connect('mongodb://test:test123@ds251197.mlab.com:51197/todo');

// create a schema

var todoSchema = new mongoose.Schema({
    item: String
});

var Todo = mongoose.model('Todo', todoSchema); //model created Todo

var urlEncodedParser = bodyParser.urlencoded({ extended: false });

//var data=[{item:'get milk'},{item:'walk dog'},{item:'run fast'}];

module.exports = function (app) {

    app.get('/todo', function (req, res) {

        //get data from mongo db and pass it to view
        // Todo.find({item:'get flowers'});   // finds a specific item
        Todo.find({}, function (err, data) { // finds all
            if (err) throw err;
            res.render("todo",{todos:data});
        });
    });

    app.post('/todo', urlEncodedParser, function (req, res) {
        // get data from the view and add to mongo db
        var newTodo = Todo(req.body).save(function (err, data) {
            if (err) throw err;
            res.json(data);
        });
    });

    app.delete('/todo/:item', function (req, res) {
        // delete requested item from mongo db
        Todo.find({ item: req.params.item.replace(/\-/g, " ") }).remove(function (err, data) {
            if (err) throw err;
            res.json(data);
        });
    });
};