module.exports = function (app, urlEncodedParser) {
    app.get('/', function (req, res) {
        res.render("home");
    });
    app.get('/home', function (req, res) {
        res.render("home");
    });
    app.post('/home', urlEncodedParser, function (req, res) {
        console.log(req.body);
        console.log(req.query);
        res.render("insurance");
    });
};