module.exports = function (app,urlEncodedParser) {
    app.get('/about', function (req, res) {
        res.render("about");
    });
};