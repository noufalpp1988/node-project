module.exports = function (app,urlEncodedParser) {
    app.get('/contact', function (req, res) {
        res.render("contact");
    });
};